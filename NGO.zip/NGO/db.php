<?php
    $server = 'localhost';
    $username ='root';
    $password ='';
    $database_name ='donate';

    $con = mysqli_connect($server,$username,$password,$database_name);
?>